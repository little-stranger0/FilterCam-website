import { createClient } from "@supabase/supabase-js";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

const supabase = createClient(supabaseUrl, supabaseAnonKey);

const loginScreen = document.getElementById("loginScreen");
const signupScreen = document.getElementById("signupScreen");
const galleryScreen = document.getElementById("galleryScreen");
const loginForm = document.getElementById("loginForm");
const signupForm = document.getElementById("signupForm");
const loginError = document.getElementById("loginError");
const signupError = document.getElementById("signupError");
const signOutBtn = document.getElementById("signOutBtn");
const photoGrid = document.getElementById("photoGrid");
const galleryStatus = document.getElementById("galleryStatus");
const refreshBtn = document.getElementById("refreshBtn");
const lightbox = document.getElementById("lightbox");
const lightboxImg = document.getElementById("lightboxImg");
const lightboxDate = document.getElementById("lightboxDate");
const downloadLink = document.getElementById("downloadLink");
const deleteBtn = document.getElementById("deleteBtn");
const lightboxClose = document.getElementById("lightboxClose");

let currentPhotoPath = null;

function setLoginError(msg) {
  loginError.textContent = msg;
}
function setSignupError(msg) {
  signupError.textContent = msg;
}

async function checkSession() {
  const { data } = await supabase.auth.getSession();
  if (data.session) {
    showGallery();
  }
}

function showGallery() {
  loginScreen.style.display = "none";
  signupScreen.style.display = "none";
  galleryScreen.style.display = "block";
  signOutBtn.style.display = "inline-block";
  loadPhotos();
}

function showLogin() {
  loginScreen.style.display = "block";
  signupScreen.style.display = "none";
  galleryScreen.style.display = "none";
  signOutBtn.style.display = "none";
}

function showSignup() {
  loginScreen.style.display = "none";
  signupScreen.style.display = "block";
  galleryScreen.style.display = "none";
  signOutBtn.style.display = "none";
}

loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  setLoginError("");
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) {
    setLoginError(error.message);
    return;
  }
  if (data.session) {
    showGallery();
  }
});

signupForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  setSignupError("");
  const email = document.getElementById("signupEmail").value.trim();
  const password = document.getElementById("signupPassword").value;

  if (password.length < 6) {
    setSignupError("Password must be at least 6 characters.");
    return;
  }

  const { data, error } = await supabase.auth.signUp({ email, password });
  if (error) {
    setSignupError(error.message);
    return;
  }
  if (data.session) {
    showGallery();
  } else {
    setSignupError("Account created. Please sign in.");
    setTimeout(() => {
      showLogin();
      document.getElementById("email").value = email;
    }, 1500);
  }
});

signOutBtn.addEventListener("click", async () => {
  await supabase.auth.signOut();
  showLogin();
});

document.getElementById("showSignup").addEventListener("click", (e) => {
  e.preventDefault();
  showSignup();
});

document.getElementById("showLogin").addEventListener("click", (e) => {
  e.preventDefault();
  showLogin();
});

refreshBtn.addEventListener("click", loadPhotos);

async function loadPhotos() {
  galleryStatus.textContent = "Loading photos...";
  photoGrid.innerHTML = "";

  try {
    const { data, error } = await supabase.storage.from("captures").list("", {
      limit: 100,
      sortBy: { column: "name", order: "desc" },
    });

    if (error) throw error;

    const folders = data.filter((item) => item.id === null || item.metadata === null);

    if (folders.length === 0 && data.length === 0) {
      galleryStatus.textContent = "No photos captured yet.";
      return;
    }

    let allPhotos = [];

    for (const folder of folders) {
      const { data: files, error: listError } = await supabase.storage
        .from("captures")
        .list(folder.name, { limit: 100, sortBy: { column: "name", order: "desc" } });

      if (listError) continue;

      for (const file of files) {
        if (file.metadata && file.metadata.size) {
          allPhotos.push({
            name: file.name,
            path: `${folder.name}/${file.name}`,
            size: file.metadata.size,
            created: file.created_at,
          });
        }
      }
    }

    allPhotos.sort((a, b) => new Date(b.created) - new Date(a.created));

    if (allPhotos.length === 0) {
      galleryStatus.textContent = "No photos captured yet.";
      return;
    }

    galleryStatus.textContent = `${allPhotos.length} photo${allPhotos.length !== 1 ? "s" : ""}`;
    renderPhotoGrid(allPhotos);
  } catch (error) {
    console.error(error);
    galleryStatus.textContent = "Failed to load photos. Make sure you are signed in.";
  }
}

function renderPhotoGrid(photos) {
  photoGrid.innerHTML = "";

  photos.forEach((photo) => {
    const item = document.createElement("div");
    item.className = "photo-item";

    const img = document.createElement("img");
    img.loading = "lazy";

    supabase.storage
      .from("captures")
      .createSignedUrl(photo.path, 60)
      .then(({ data }) => {
        if (data) img.src = data.signedUrl;
      });

    img.addEventListener("click", () => openLightbox(photo));
    item.appendChild(img);

    const overlay = document.createElement("div");
    overlay.className = "photo-overlay";
    overlay.textContent = photo.path.split("/")[0];
    item.appendChild(overlay);

    photoGrid.appendChild(item);
  });
}

async function openLightbox(photo) {
  currentPhotoPath = photo.path;

  const { data, error } = await supabase.storage
    .from("captures")
    .createSignedUrl(photo.path, 3600);

  if (error || !data) {
    galleryStatus.textContent = "Failed to load photo.";
    return;
  }

  lightboxImg.src = data.signedUrl;
  lightboxDate.textContent = photo.path;
  downloadLink.href = data.signedUrl;
  downloadLink.download = photo.name;
  lightbox.style.display = "flex";
}

function closeLightbox() {
  lightbox.style.display = "none";
  lightboxImg.src = "";
  currentPhotoPath = null;
}

lightboxClose.addEventListener("click", closeLightbox);
document.querySelector(".lightbox-backdrop").addEventListener("click", closeLightbox);

deleteBtn.addEventListener("click", async () => {
  if (!currentPhotoPath) return;
  if (!confirm("Delete this photo? This cannot be undone.")) return;

  deleteBtn.disabled = true;
  deleteBtn.textContent = "Deleting...";

  const { error } = await supabase.storage
    .from("captures")
    .remove([currentPhotoPath]);

  deleteBtn.disabled = false;
  deleteBtn.textContent = "Delete";

  if (error) {
    galleryStatus.textContent = "Failed to delete photo.";
    return;
  }

  closeLightbox();
  loadPhotos();
});

checkSession();
