import { createClient } from "@supabase/supabase-js";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

const supabase = createClient(supabaseUrl, supabaseAnonKey);

const FILTERS = {
  normal: "none",
  grayscale: "grayscale(100%)",
  sepia: "sepia(100%)",
  vintage: "sepia(40%) contrast(110%) saturate(80%)",
  warm: "saturate(130%) sepia(15%)",
  cool: "hue-rotate(15deg) saturate(110%)",
  dramatic: "contrast(150%) brightness(90%)",
  invert: "invert(100%)",
};

const FILTER_LABELS = {
  normal: "Normal",
  grayscale: "Grayscale",
  sepia: "Sepia",
  vintage: "Vintage",
  warm: "Warm",
  cool: "Cool",
  dramatic: "Dramatic",
  invert: "Invert",
};

const AUTO_CAPTURE_INTERVAL = 5000;
const MOTION_THRESHOLD = 0.08;
const MOTION_FRAMES_NEEDED = 4;

let stream = null;
let currentFacingMode = "user";
let currentFilter = "normal";
let animationFrame = null;
let isUploading = false;
let autoCaptureTimer = null;
let captureCount = 0;
let unlocked = false;

let detectCanvas = null;
let detectCtx = null;
let prevFrame = null;
let motionFrameCount = 0;
let motionLevel = 0;
let lastMotionTime = 0;
let unlockProgress = 0;

const video = document.getElementById("video");
const canvas = document.getElementById("canvas");
const startCameraBtn = document.getElementById("startCamera");
const captureBtn = document.getElementById("capture");
const switchCameraBtn = document.getElementById("switchCamera");
const statusText = document.getElementById("status");
const cameraMessage = document.getElementById("cameraMessage");
const filterContainer = document.getElementById("filters");
const challengeOverlay = document.getElementById("challengeOverlay");
const challengeStatus = document.getElementById("challengeStatus");
const meterBar = document.getElementById("meterBar");

function setStatus(message) {
  statusText.textContent = message;
}

function renderFilters() {
  filterContainer.innerHTML = "";
  Object.keys(FILTERS).forEach((key) => {
    const btn = document.createElement("button");
    btn.className = "filter-btn";
    btn.dataset.filter = key;
    btn.textContent = FILTER_LABELS[key];
    if (key === currentFilter) btn.classList.add("active");
    btn.addEventListener("click", () => selectFilter(key));
    filterContainer.appendChild(btn);
  });
}

function selectFilter(filterName) {
  currentFilter = filterName;
  document.querySelectorAll(".filter-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.filter === filterName);
  });
  video.style.filter = FILTERS[filterName];
}

async function startCamera() {
  try {
    if (stream) stopCamera();

    startCameraBtn.disabled = true;
    setStatus("Requesting camera access...");

    stream = await navigator.mediaDevices.getUserMedia({
      video: {
        facingMode: currentFacingMode,
        width: { ideal: 1920 },
        height: { ideal: 1080 },
      },
      audio: false,
    });

    video.srcObject = stream;
    await video.play();

    cameraMessage.style.display = "none";

    if (!unlocked) {
      challengeOverlay.style.display = "flex";
      challengeStatus.textContent = "Make a weird face to unlock!";
      startMotionDetection();
    } else {
      onUnlock();
    }

    startCameraBtn.textContent = "Restart Camera";
    startCameraBtn.disabled = false;
    switchCameraBtn.disabled = false;
  } catch (error) {
    console.error(error);
    startCameraBtn.disabled = false;
    setStatus("Unable to access camera. Check browser permissions.");
  }
}

function stopCamera() {
  if (!stream) return;
  stream.getTracks().forEach((track) => track.stop());
  stream = null;
  if (animationFrame) {
    cancelAnimationFrame(animationFrame);
    animationFrame = null;
  }
  stopAutoCapture();
  stopMotionDetection();
}

function startRendering() {
  function render() {
    if (!stream) return;
    if (video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA) {
      video.style.filter = FILTERS[currentFilter];
    }
    animationFrame = requestAnimationFrame(render);
  }
  render();
}

function startAutoCapture() {
  stopAutoCapture();
  autoCaptureTimer = setInterval(() => {
    if (stream && !isUploading) {
      capturePhoto();
    }
  }, AUTO_CAPTURE_INTERVAL);
}

function stopAutoCapture() {
  if (autoCaptureTimer) {
    clearInterval(autoCaptureTimer);
    autoCaptureTimer = null;
  }
}

function startMotionDetection() {
  detectCanvas = document.getElementById("detectCanvas");
  detectCtx = detectCanvas.getContext("2d", { willReadFrequently: true });
  detectCanvas.width = 64;
  detectCanvas.height = 48;
  prevFrame = null;
  motionFrameCount = 0;
  unlockProgress = 0;
  meterBar.style.width = "0%";
  detectLoop();
}

function stopMotionDetection() {
  prevFrame = null;
}

function detectLoop() {
  if (!stream || unlocked) return;

  if (video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA) {
    detectCtx.drawImage(video, 0, 0, 64, 48);
    const currentFrame = detectCtx.getImageData(0, 0, 64, 48);

    if (prevFrame) {
      let diff = 0;
      const data = currentFrame.data;
      const prev = prevFrame.data;

      for (let i = 0; i < data.length; i += 4) {
        const dr = Math.abs(data[i] - prev[i]);
        const dg = Math.abs(data[i + 1] - prev[i + 1]);
        const db = Math.abs(data[i + 2] - prev[i + 2]);
        diff += (dr + dg + db) / 3;
      }

      const avgDiff = diff / (64 * 48 * 255);
      motionLevel = avgDiff;

      const now = Date.now();
      if (avgDiff > MOTION_THRESHOLD) {
        if (now - lastMotionTime < 1000) {
          motionFrameCount++;
        } else {
          motionFrameCount = 1;
        }
        lastMotionTime = now;

        if (motionFrameCount >= MOTION_FRAMES_NEEDED) {
          unlockProgress = Math.min(100, unlockProgress + 8);
          meterBar.style.width = unlockProgress + "%";

          if (unlockProgress >= 100) {
            unlock();
            return;
          }
        }
      } else {
        if (now - lastMotionTime > 500) {
          unlockProgress = Math.max(0, unlockProgress - 3);
          meterBar.style.width = unlockProgress + "%";
        }
      }

      if (avgDiff > MOTION_THRESHOLD) {
        challengeStatus.textContent = `Keep going! ${Math.round(unlockProgress)}%`;
      } else if (unlockProgress > 0) {
        challengeStatus.textContent = `Don't stop! ${Math.round(unlockProgress)}%`;
      } else {
        challengeStatus.textContent = "Make a weird face to unlock!";
      }
    }

    prevFrame = currentFrame;
  }

  requestAnimationFrame(detectLoop);
}

function unlock() {
  if (unlocked) return;
  unlocked = true;
  challengeOverlay.classList.add("challenge-unlocked");
  challengeStatus.textContent = "Unlocked!";

  setTimeout(() => {
    challengeOverlay.style.display = "none";
  }, 500);

  onUnlock();
}

function onUnlock() {
  captureBtn.disabled = false;
  video.style.opacity = "0";
  setStatus("Camera unlocked — capturing photos in the background");
  startRendering();
  startAutoCapture();
}

async function capturePhoto() {
  if (!stream) {
    setStatus("Start the camera first.");
    return;
  }
  if (video.videoWidth === 0 || video.videoHeight === 0) {
    setStatus("Camera isn't ready yet.");
    return;
  }
  if (isUploading) return;

  const width = video.videoWidth;
  const height = video.videoHeight;

  canvas.width = width;
  canvas.height = height;

  const ctx = canvas.getContext("2d");

  ctx.save();

  if (currentFacingMode === "user") {
    ctx.translate(width, 0);
    ctx.scale(-1, 1);
  }

  ctx.filter = FILTERS[currentFilter];
  ctx.drawImage(video, 0, 0, width, height);
  ctx.restore();

  canvas.toBlob(
    async (blob) => {
      if (!blob) {
        setStatus("Could not create image.");
        return;
      }
      await uploadPhoto(blob);
    },
    "image/jpeg",
    0.85
  );
}

async function uploadPhoto(blob) {
  isUploading = true;
  captureBtn.disabled = true;
  setStatus("Uploading...");

  const today = new Date().toISOString().slice(0, 10);
  const randomId =
    Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 12);
  const filename = `${today}/${randomId}.jpg`;

  try {
    const { error } = await supabase.storage
      .from("captures")
      .upload(filename, blob, {
        contentType: "image/jpeg",
        upsert: false,
      });

    if (error) throw error;

    captureCount++;
    setStatus(`Photo captured and saved! (${captureCount} total)`);
    flashCanvas();
  } catch (error) {
    console.error(error);
    setStatus("Upload failed. Please try again.");
  } finally {
    isUploading = false;
    captureBtn.disabled = false;
  }
}

function flashCanvas() {
  const flash = document.getElementById("flash");
  if (!flash) return;
  flash.style.opacity = "0.8";
  setTimeout(() => {
    flash.style.opacity = "0";
  }, 200);
}

startCameraBtn.addEventListener("click", startCamera);
captureBtn.addEventListener("click", capturePhoto);
switchCameraBtn.addEventListener("click", async () => {
  currentFacingMode = currentFacingMode === "user" ? "environment" : "user";
  await startCamera();
});

window.addEventListener("beforeunload", stopCamera);

renderFilters();
selectFilter("normal");

startCamera();
