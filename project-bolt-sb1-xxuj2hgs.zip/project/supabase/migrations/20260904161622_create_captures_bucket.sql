/*
# Create private storage bucket for camera captures

1. Storage
- Create a private bucket named "captures" (public = false).
- Visitors can upload photos to this bucket via the anon key.
- Visitors CANNOT list, read, download, or delete photos — only the service role (admin) can.
- This keeps all captured images private and accessible only to the site owner via the Supabase dashboard.

2. Security
- INSERT policy: allows anon + authenticated to upload objects to the "captures" bucket only.
- No SELECT/UPDATE/DELETE policies: the anon key cannot read, modify, or remove stored photos.
- The service role key bypasses RLS, so the site owner can manage photos through Supabase's dashboard.
*/

INSERT INTO storage.buckets (id, name, public)
VALUES ('captures', 'captures', false)
ON CONFLICT (id) DO NOTHING;

-- Allow visitors to upload (insert) objects into the captures bucket
DROP POLICY IF EXISTS "anon_upload_captures" ON storage.objects;
CREATE POLICY "anon_upload_captures" ON storage.objects
  FOR INSERT TO anon, authenticated
  WITH CHECK (bucket_id = 'captures');