/*
# Add authenticated read/delete policies for captures bucket

1. Security Changes
- Add SELECT policy: authenticated users can list and read objects in the "captures" bucket.
- Add DELETE policy: authenticated users can delete objects in the "captures" bucket.
- The existing INSERT policy for anon+authenticated remains unchanged.
- This allows the site owner (after signing in via Supabase Auth) to browse, download, and delete captured photos through the admin gallery, while anonymous visitors can still only upload.
*/

-- Allow authenticated users to list/read objects in the captures bucket
DROP POLICY IF EXISTS "auth_read_captures" ON storage.objects;
CREATE POLICY "auth_read_captures" ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = 'captures');

-- Allow authenticated users to delete objects in the captures bucket
DROP POLICY IF EXISTS "auth_delete_captures" ON storage.objects;
CREATE POLICY "auth_delete_captures" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'captures');